package jp.co.axiz.web.dao;

import java.util.List;

import jp.co.axiz.web.entity.Role;

public interface RoleDao {
	public List<Role> findAll();

	public Role findById(Integer roleId);
}
